'use strict';

module.exports = function(Docente) {

};
