'use strict';

module.exports = function(Asignatura) {

};
