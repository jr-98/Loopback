'use strict';

module.exports = function(Estudiante) {

};
