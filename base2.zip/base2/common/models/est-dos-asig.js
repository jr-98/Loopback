'use strict';

module.exports = function(Estdosasig) {

};
