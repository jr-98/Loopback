'use strict';

module.exports = function(Lugares) {

};
